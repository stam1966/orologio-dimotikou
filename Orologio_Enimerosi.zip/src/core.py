"""Independent timetable model. No aSc binaries or code required."""
import copy, json, os, re, tempfile, uuid, itertools
import rules as R
from pathlib import Path
from collections import Counter, defaultdict
import xml.etree.ElementTree as ET

VERSION = '0.36.3-beta'
DAYS = ['Δευτέρα','Τρίτη','Τετάρτη','Πέμπτη','Παρασκευή']
def uid(): return uuid.uuid4().hex[:16]
def blank():
    return dict(schema=1,version=VERSION,title='Ωρολόγιο Σχολείου',school='',year='',days=DAYS[:],periods=[],teachers=[],classes=[],subjects=[],rooms=[],groups=[],lessons=[],events=[],teacher_rules={},class_rules={},subject_rules={},global_rules={'min_gaps':{'w':1,'on':True}})
def mapping(p,k): return {x['id']:x for x in p[k]}
def split(s): return [x for x in s.split(',') if x]
def slots(p): return [[d,i] for d in range(5) for i in range(len(p['periods']))]
def import_xml(raw):
    if len(raw)>10_000_000: raise ValueError('Το XML υπερβαίνει τα 10 MB.')
    r=ET.fromstring(raw)
    if r.tag=='orologio':
        from outputs import import_native
        return import_native(r)
    if r.tag!='timetable':raise ValueError('Αναμένεται XML aSc TimeTables.')
    p=blank(); p['source_version']=r.get('ascttversion','');p['title']='Πρόγραμμα από XML'
    def rows(k):return [x.attrib for x in r.findall(k+'/*')]
    per=sorted(rows('periods'),key=lambda x:int(x['period']))
    p['periods']=[dict(id=x['period'],name=x.get('name',x['period']),start=x['starttime'],end=x['endtime']) for x in per]
    pi={x['id']:i for i,x in enumerate(p['periods'])}
    for key,src in [('teachers','teachers'),('subjects','subjects'),('classes','classes'),('rooms','classrooms')]:
        p[key]=[dict(id=x['id'],name=x['name'],short=x.get('short',x['name'])) for x in rows(src)]
    # Χρώμα εκπαιδευτικού και υπεύθυνος τμήματος, όπως ορίζονται στο aSc
    tcol={x['id']:x.get('color','') for x in rows('teachers')}
    for t in p['teachers']:
        c=tcol.get(t['id'],'')
        if re.fullmatch(r'#[0-9A-Fa-f]{6}',c or ''):t['color']=c.upper()
    tids={t['id'] for t in p['teachers']};ctea={x['id']:x.get('teacherid','') for x in rows('classes')}
    for c in p['classes']:
        if ctea.get(c['id']) in tids:c['teacher']=ctea[c['id']]
    p['groups']=rows('groups')
    for x in rows('weeksdefs'):
        if x['weeks']!='1':raise ValueError('Η πρώτη έκδοση υποστηρίζει ένα εβδομαδιαίο πρόγραμμα.')
    for x in rows('termsdefs'):
        if x['terms']!='1':raise ValueError('Δεν υποστηρίζονται πολλαπλές περίοδοι έτους.')
    dd={x['id']:x['days'] for x in rows('daysdefs')}
    cards=defaultdict(list)
    for x in rows('cards'):
        if len(x['days'])!=5 or x.get('weeks','1')!='1' or x.get('terms','1')!='1':raise ValueError('Μη υποστηριζόμενη εβδομάδα / ημέρες.')
        for d,b in enumerate(x['days']):
            if b=='1':cards[x['lessonid']].append((d,pi[x['period']]))
    for x in rows('lessons'):
        dur=int(x['periodspercard']);hours=float(x['periodsperweek'])
        if dur<1 or not hours.is_integer() or int(hours)%dur:raise ValueError('Μη ακέραιη κατανομή ωρών στην ανάθεση '+x['id'])
        rooms=split(x.get('classroomids',''))
        if len(rooms)>1:raise ValueError('Η πρώτη έκδοση απαιτεί μία σταθερή αίθουσα ανά ανάθεση.')
        days=dd.get(x.get('daysdefid'),'10000,01000,00100,00010,00001')
        allowed=sorted({i for bit in days.split(',') for i,b in enumerate(bit) if b=='1'})
        l=dict(id=x['id'],subject=x['subjectid'],teachers=split(x['teacherids']),classes=split(x['classids']),groups=split(x.get('groupids','')),room=rooms[0] if rooms else '',hours=int(hours),duration=dur,days=allowed,max_daily=0)
        p['lessons'].append(l)
        remaining=sorted(cards.pop(x['id'],[]))
        placements=[]
        while remaining:
            d,i=remaining[0];chunk=[(d,i+j) for j in range(dur)]
            if not all(a in remaining for a in chunk):raise ValueError('Οι συνεχόμενες ώρες δεν ομαδοποιούνται με ασφάλεια: '+x['id'])
            for a in chunk:remaining.remove(a)
            placements.append([d,i])
        if len(placements)>int(hours)//dur:raise ValueError('Περισσότερες τοποθετήσεις από τις ώρες ανάθεσης.')
        for n in range(int(hours)//dur):p['events'].append(dict(id=uid(),lesson=l['id'],place=placements[n] if n<len(placements) else None,locked=False))
    if cards:raise ValueError('Το XML έχει τοποθετήσεις άγνωστης ανάθεσης.')
    # Suggested class windows only; teacher availability is never inferred.
    for c in p['classes']:
        observed=set()
        for e in p['events']:
            l=next(l for l in p['lessons'] if l['id']==e['lesson'])
            if c['id'] in l['classes'] and e['place']:
                observed.update(range(e['place'][1],e['place'][1]+l['duration']))
        p['class_rules'][c['id']]=dict(allowed=[[d,i] for d in range(5) for i in sorted(observed)] if observed else slots(p))
    check_structure(p)
    return p

def check_structure(p):
    if p.get('schema')!=1:raise ValueError('Μη υποστηριζόμενη μορφή έργου.')
    if len(p['days'])!=5 or not 1<=len(p['periods'])<=20:raise ValueError('Απαιτούνται 5 ημέρες και 1–20 περίοδοι.')
    for key in ['teachers','classes','subjects','rooms','groups','lessons','events']:
        ids=[x['id'] for x in p[key]]
        if len(ids)!=len(set(ids)):raise ValueError('Διπλό αναγνωριστικό: '+key)
    for period in p['periods']:
        for k in ['start','end']:
            h,m=map(int,period[k].split(':'))
            if not (0<=h<24 and 0<=m<60):raise ValueError('Μη έγκυρη ώρα.')
        if minutes(period['start'])>=minutes(period['end']):raise ValueError('Η λήξη περιόδου πρέπει να είναι μετά την έναρξη.')
    for a,b in zip(p['periods'],p['periods'][1:]):
        if minutes(a['end'])>minutes(b['start']):raise ValueError('Επικάλυψη χρονικών περιόδων.')
    ids={k:set(mapping(p,k)) for k in ['teachers','classes','subjects','rooms','groups','lessons']}
    for g in p['groups']:
        if g['classid'] not in ids['classes']:raise ValueError('Άγνωστο τμήμα ομάδας.')
    for l in p['lessons']:
        if l['subject'] not in ids['subjects']:raise ValueError('Άγνωστο μάθημα.')
        for k in ['teachers','classes','groups']:
            if not set(l[k])<=ids[k]:raise ValueError('Άγνωστη αναφορά '+k)
        if not l['teachers']:raise ValueError('Κάθε ανάθεση χρειάζεται εκπαιδευτικό.')
        if l['room'] and l['room'] not in ids['rooms']:raise ValueError('Άγνωστη αίθουσα.')
        if not isinstance(l['hours'],int) or not isinstance(l['duration'],int) or l['hours']<1 or not 1<=l['duration']<=len(p['periods']) or l['hours']%l['duration']:raise ValueError('Οι ώρες πρέπει να διαιρούνται με τη διάρκεια.')
        if not l['days'] or any(d not in range(5) for d in l['days']):raise ValueError('Μη έγκυρες ημέρες.')
        if not isinstance(l.get('max_daily',0),int) or l.get('max_daily',0)<0:raise ValueError('Μη έγκυρο ημερήσιο όριο μαθήματος.')
    counts=Counter(e['lesson'] for e in p['events'])
    for e in p['events']:
        if e['lesson'] not in ids['lessons']:raise ValueError('Άγνωστη ανάθεση τοποθέτησης.')
        if e['locked'] and e['place'] is None:raise ValueError('Δεν κλειδώνεται ατοποθέτητη διδασκαλία.')
        if e['place'] is not None:
            if len(e['place'])!=2 or any(type(v)!=int for v in e['place']) or e['place'][0] not in range(5) or e['place'][1] not in range(len(p['periods'])):raise ValueError('Μη έγκυρη θέση.')
    for l in p['lessons']:
        if counts[l['id']]!=l['hours']//l['duration']:raise ValueError('Ασυμφωνία πλήθους διδασκαλιών.')
    n=len(p['periods'])
    for t in p['teachers']:
        if t.get('color') and not re.fullmatch(r'#[0-9A-Fa-f]{6}',t['color']):raise ValueError('Μη έγκυρο χρώμα εκπαιδευτικού.')
    for c in p['classes']:
        if c.get('teacher') and c['teacher'] not in ids['teachers']:raise ValueError('Άγνωστος υπεύθυνος τμήματος.')
    for l in p['lessons']:
        if type(l.get('exempt_subject_limit',False))!=bool:raise ValueError('Μη έγκυρη εξαίρεση ανάθεσης.')
        if type(l.get('joint',False))!=bool or type(l.get('joint_deduct',False))!=bool:raise ValueError('Μη έγκυρη συνδιδασκαλία τάξεων.')
    for key,entities in [('teacher_rules','teachers'),('class_rules','classes'),('subject_rules','subjects')]:
        for id,rule in p.get(key,{}).items():
            if id not in ids[entities]:raise ValueError('Κανόνας άγνωστης οντότητας.')
            for old in R.REMOVED.get(entities,()):rule.pop(old,None)
            for field in ('allowed','avoid'):
                for d,i in rule.get(field,[]):
                    if type(d)!=int or type(i)!=int or d not in range(5) or i not in range(n):raise ValueError('Μη έγκυρη διαθεσιμότητα.')
            if rule.get('avoid_w',3) not in (1,2,3,4,5):raise ValueError('Μη έγκυρη βαρύτητα θέσεων «υπό όρους».')
            for k,v in rule.items():
                if k in ('allowed','avoid','avoid_w','start_counts'):continue
                if k not in R.TYPES[entities]:raise ValueError('Άγνωστος κανόνας: '+k)
                R.check_rule_value(entities,k,v,n)
            mx=R.norm(rule.get('max_daily'));mn=R.norm(rule.get('min_daily'))
            if mx and mn and mx['w']==0 and mn['w']==0 and mn['v']>mx['v']:raise ValueError('Ελάχιστο μεγαλύτερο από μέγιστο.')
            for k,v in rule.get('start_counts',{}).items():
                if int(k) not in range(n) or type(v)!=int or not 0<=v<=5:raise ValueError('Μη έγκυρος αριθμός ημερών έναρξης.')
    for c in p['classes']:
        if c.get('grade') is not None and (type(c['grade'])!=str or len(c['grade'])>10):raise ValueError('Μη έγκυρη τάξη τμήματος.')
    for t in p['teachers']:
        if t.get('years') is not None and (type(t['years'])!=int or not 0<=t['years']<=60):raise ValueError('Μη έγκυρα έτη υπηρεσίας.')
        if t.get('years_m') is not None and (type(t['years_m'])!=int or not 0<=t['years_m']<=11):raise ValueError('Μη έγκυροι μήνες υπηρεσίας.')
        if t.get('years_d') is not None and (type(t['years_d'])!=int or not 0<=t['years_d']<=30):raise ValueError('Μη έγκυρες ημέρες υπηρεσίας.')
        for k in ('active','special','hypothetical'):
            if k in t and type(t[k])!=bool:raise ValueError('Μη έγκυρο πεδίο εκπαιδευτικού: '+k)
        if 'spec' in t and (not isinstance(t['spec'],str) or len(t['spec'])>40):raise ValueError('Μη έγκυρη ειδικότητα.')
        if t.get('role','') not in ROLES:raise ValueError('Μη έγκυρος ρόλος εκπαιδευτικού.')
        if t.get('hours_override') is not None and (type(t['hours_override'])!=int or not 0<=t['hours_override']<=40):raise ValueError('Μη έγκυρο ωράριο εκπαιδευτικού.')
    if p.get('positions') is not None and (type(p['positions'])!=int or not 1<=p['positions']<=60):raise ValueError('Μη έγκυρη οργανικότητα σχολείου.')
    fw=p.get('framework')
    if fw is not None:
        if not isinstance(fw,dict):raise ValueError('Μη έγκυρο θεσμικό πλαίσιο.')
        if fw.get('level','Δημοτικό') not in LEVELS:raise ValueError('Μη έγκυρη βαθμίδα.')
        th=fw.get('teacher_hours') or {}
        for key in ('bands','director'):
            for row in th.get(key,[]):
                if not (isinstance(row,list) and len(row) in ((3,4) if key=='director' else (3,)) and all(type(x)==int and 0<=x<=99 for x in row) and row[0]<=row[1]):raise ValueError('Μη έγκυρη γραμμή ωραρίου εκπαιδευτικών.')
        if 'bands_upto' in th and type(th['bands_upto'])!=bool:raise ValueError('Μη έγκυρο πεδίο ωραρίου.')
        if 'director_years' in th and (type(th['director_years'])!=int or not 0<=th['director_years']<=60):raise ValueError('Μη έγκυρα έτη υπηρεσίας διευθυντή.')
        dh=th.get('deputy_hours')
        if dh is not None and not (isinstance(dh,list) and len(dh) in (0,2) and all(type(x)==int and 0<=x<=40 for x in dh)):raise ValueError('Μη έγκυρο ωράριο υποδιευθυντών.')
        for key in ('small_school_max','small_school_hours','deputy_reduction'):
            if key in th and (type(th[key])!=int or not 0<=th[key]<=40):raise ValueError('Μη έγκυρη τιμή ωραρίου εκπαιδευτικών.')
    cur=p.get('curriculum',{})
    if not isinstance(cur,dict):raise ValueError('Μη έγκυρο επίσημο ωρολόγιο.')
    if fw is not None and fw.get('optional') is not None:
        op=fw['optional']
        if not isinstance(op,dict) or any(type(g)!=str or not isinstance(l,list) or any(x not in ids['subjects'] for x in l) for g,l in op.items()):raise ValueError('Μη έγκυρα προαιρετικά μαθήματα θεσμικού πλαισίου.')
    for gr,row in cur.items():
        if type(gr)!=str or not isinstance(row,dict):raise ValueError('Μη έγκυρο επίσημο ωρολόγιο.')
        for sid,h in row.items():
            if sid not in ids['subjects'] or type(h)!=int or not 0<=h<=40:raise ValueError('Μη έγκυρη τιμή στο επίσημο ωρολόγιο.')
    import subs, admin
    subs.validate(p,ids);admin.validate(p,ids)
    lk=p.get('links')
    if lk is not None:
        if not isinstance(lk,list):raise ValueError('Μη έγκυρα ταυτόχρονα μαθήματα.')
        lids=set(ids['lessons']);clean=[];seen=set()
        for k in lk:
            if not isinstance(k,dict) or not isinstance(k.get('lessons'),list):raise ValueError('Μη έγκυρα ταυτόχρονα μαθήματα.')
            les=[x for x in dict.fromkeys(k['lessons']) if isinstance(x,str) and x in lids]
            kid=str(k.get('id') or uid())
            if len(les)>=2 and kid not in seen:
                seen.add(kid);clean.append(dict(id=kid,lessons=les,note=str(k.get('note',''))[:200]))
        p['links']=clean
    g=p.get('global_rules',{}).get('min_gaps')
    if g is not None and (not isinstance(g,dict) or g.get('w',1) not in (1,2,3,4,5)):raise ValueError('Μη έγκυρος γενικός κανόνας κενών.')
    return p

def minutes(s):h,m=map(int,s.split(':'));return 60*h+m

def resources(p,l):return R.resources(p,l)
def candidates(p,l):return R.candidates(p,l)

def slot_status(p,event_id):
    """Για χειροκίνητη μετακίνηση. Επιστρέφει {'st':{"d,i":κατάσταση}, 'why':{"d,i":αιτιολογία}}.
    Κατάσταση: ok / maybe (θέση «υπό όρους») / busy (σύγκρουση) / no (απαγορεύεται από κανόνα)."""
    ls=mapping(p,'lessons');e=next(x for x in p['events'] if x['id']==event_id);l=ls[e['lesson']];n=len(p['periods']);dur=l['duration']
    em={t:r for t,r in R.earliest_map(p).items() if r['w']==0}
    res=R.resources(p,l);occ={}
    tday={};subjday={};lessonday={};dayend_subj={}
    S=mapping(p,'subjects');T=mapping(p,'teachers');C=mapping(p,'classes')
    for x in p['events']:
        if x['id']==event_id or not x['place']:continue
        lx=ls[x['lesson']];d0,i0=x['place']
        for j in range(i0,i0+lx['duration']):
            for r in R.resources(p,lx):occ[(r,d0,j)]=lx
            for t in lx['teachers']:tday.setdefault((t,d0),set()).add(j)
        if not lx.get('exempt_subject_limit'):
            for c in lx['classes']:subjday[(lx['subject'],c,d0)]=subjday.get((lx['subject'],c,d0),0)+1
        lessonday[(lx['id'],d0)]=lessonday.get((lx['id'],d0),0)+lx['duration']
        for t in lx['teachers']:
            r=R.rule(p,'subjects',lx['subject'],'day_end')
            if r and r['w']==0:dayend_subj.setdefault((t,d0),[]).append((r['v'],lx['subject']))
    av=[(R.avoid(p,'teachers',t)[0],T[t]['name']) for t in l['teachers']]+[(R.avoid(p,'classes',c)[0],C[c]['name']) for c in l['classes']]+[(R.avoid(p,'subjects',l['subject'])[0],S[l['subject']]['name'])]
    lim=R.subject_limit(p,l['subject']);own_end=R.rule(p,'subjects',l['subject'],'day_end')
    st={};why={}
    def who(lx):
        return S[lx['subject']]['name']+' ('+', '.join(C[c].get('short') or C[c]['name'] for c in lx['classes'])+(', ' if lx['classes'] else '')+', '.join(T[t]['name'] for t in lx['teachers'])+')'
    for d in range(5):
        for i in range(n):
            k=f'{d},{i}';cover=range(i,i+dur)
            if i>n-dur:st[k]='no';why[k]='Δεν χωράει: χρειάζονται '+str(dur)+' συνεχόμενες ώρες.';continue
            keys=R.forbid_keys(p,l,d,i,em)
            if keys:st[k]='no';why[k]='; '.join(R.describe(p,x) for x in keys);continue
            clash=[]
            for j in cover:
                for r in res:
                    if (r,d,j) in occ:
                        lx=occ[(r,d,j)];sn=S[lx['subject']]['name']
                        if r.startswith('t:'):txt=T[r[2:]]['name']+': διδάσκει ήδη '+sn+(' στο '+', '.join(C[c]['name'] for c in lx['classes']) if lx['classes'] else '')+' ('+p['periods'][j]['name']+'η ώρα)'
                        elif r.startswith('c:'):txt=C[r.split(':')[1]]['name']+': έχει ήδη '+sn+' με '+', '.join(T[t]['name'] for t in lx['teachers'])+' ('+p['periods'][j]['name']+'η ώρα)'
                        else:txt='Η αίθουσα είναι κατειλημμένη: '+who(lx)
                        if txt not in clash:clash.append(txt)
            if clash:st[k]='busy';why[k]='; '.join(clash);continue
            rules=[]
            if lim and lim['w']==0 and not l.get('exempt_subject_limit'):
                for c in l['classes']:
                    if subjday.get((l['subject'],c,d),0)+1>lim['v']:rules.append(S[l['subject']]['name']+': ήδη '+str(subjday.get((l['subject'],c,d),0))+' φορά/ές '+p['days'][d]+' στο '+C[c]['name']+' (μέγιστο '+str(lim['v'])+')')
            if l.get('max_daily') and lessonday.get((l['id'],d),0)+dur>l['max_daily']:rules.append('Μέγιστες ώρες/ημέρα της ανάθεσης ('+str(l['max_daily'])+')')
            for t in l['teachers']:
                mx=R.rule(p,'teachers',t,'max_daily');used=tday.get((t,d),set())
                if mx and mx['w']==0 and len(used|set(cover))>mx['v']:rules.append(T[t]['name']+': ξεπερνά τις '+str(mx['v'])+' ώρες την ημέρα')
                for v,sid in dayend_subj.get((t,d),[]):
                    if i+dur-1>v:rules.append(T[t]['name']+': έχει '+S[sid]['name']+' εκείνη την ημέρα και πρέπει να τελειώσει έως '+p['periods'][v]['end'])
                if own_end and own_end['w']==0 and any(j>own_end['v'] for j in used):rules.append(T[t]['name']+': διδάσκει μετά τις '+p['periods'][own_end['v']]['end']+' εκείνη την ημέρα· με '+S[l['subject']]['name']+' πρέπει να τελειώνει νωρίτερα')
            if rules:st[k]='no';why[k]='; '.join(rules);continue
            soft=[nm for a,nm in av if any((d,j) in a for j in cover)]
            if soft:st[k]='maybe';why[k]='Υπό όρους (επιτρέπεται, αλλά καλύτερα να αποφεύγεται) για: '+', '.join(soft)
            else:st[k]='ok';why[k]='Ελεύθερη θέση'
    if e['place']:
        k=f"{e['place'][0]},{e['place'][1]}";st[k]='cur';why[k]='Τρέχουσα θέση'
    return {'st':st,'why':why}

GRADES=['Α','Β','Γ','Δ','Ε','ΣΤ']
def grade_of(c):
    """Τάξη τμήματος: ρητή ή από το όνομα (π.χ. «Α Τάξη», «Β1», «ΣΤ2»)."""
    if c.get('grade'):return c['grade']
    for txt in (c.get('short') or '',c['name']):
        t=txt.upper().replace('Τ΄','Τ').strip()
        for g in sorted(GRADES,key=len,reverse=True):
            if t==g or (t.startswith(g) and (len(t)==len(g) or t[len(g)] in ' 0123456789΄\'-')):return g
    return ''

# ---------------------------------------------------------------- θεσμικό πλαίσιο
TEACHER_HOURS_DEFAULT={
    'source':'ν. 1566/1985, άρθρο 13, παρ. 7 (όπως ισχύει) — ελέγξτε το ισχύον ΦΕΚ',
    'bands':[[0,10,24],[10,15,23],[15,20,22],[20,99,21]],   # [από έτη, έως έτη (χωρίς), ώρες]
    'small_school_max':3,'small_school_hours':25,             # 1θέσια έως 3θέσια
    'director':[[4,5,18],[6,9,10],[10,11,8],[12,99,6]],       # [από θέσεις, έως θέσεις, ώρες]
    'deputy_reduction':2}
TEACHER_HOURS_SECONDARY={
    'source':'ν. 1566/1985, άρθρο 14, παρ. 13 και ν. 4152/2013, υποπ. Θ1 (δευτεροβάθμια, όπως ισχύει) — ελέγξτε το ισχύον ΦΕΚ',
    'bands':[[0,6,23],[6,12,21],[12,20,20],[20,99,18]],'bands_upto':True,   # «έως 6 έτη», «6 έτη και 1 ημέρα έως 12»…
    'small_school_max':0,'small_school_hours':0,
    # διευθυντές Γυμνασίων/Λυκείων: [από τμήματα, έως τμήματα, ώρες, ώρες με υπηρεσία πάνω από director_years έτη]
    'director':[[3,5,10,8],[6,9,9,7],[10,12,7,5],[13,99,5,3]],'director_years':20,'deputy_reduction':0,
    # υποδιευθυντές Γυμνασίων/Λυκείων: σταθερό ωράριο [έως director_years έτη, πάνω από director_years έτη]
    'deputy_hours':[16,14]}
LEVELS=('Δημοτικό','Γυμνάσιο','Λύκειο')
LEVEL_GRADES={'Δημοτικό':['Α','Β','Γ','Δ','Ε','ΣΤ'],'Γυμνάσιο':['Α','Β','Γ'],'Λύκειο':['Α','Β','Γ']}
ROLES={'':'Εκπαιδευτικός','director':'Διευθυντής/ντρια','deputy':'Υποδιευθυντής/ντρια'}

def guess_level(p):
    """Βαθμίδα από τα δεδομένα μιας εισαγωγής aSc (που δεν τη γράφει): τάξεις Δ–ΣΤ → Δημοτικό· μαθήματα
    Γυμνασίου/Λυκείου (Αρχαία, Χημεία, Βιολογία, Άλγεβρα…) → Γυμνάσιο ή Λύκειο."""
    import unicodedata
    up = lambda x: ''.join(ch for ch in unicodedata.normalize('NFD', (x or '').upper()) if unicodedata.category(ch) != 'Mn')
    gs = {grade_of(c) for c in p.get('classes', [])}
    if gs & {'Δ', 'Ε', 'ΣΤ'}:
        return 'Δημοτικό'
    txt = ' '.join(up(s.get('name')) for s in p.get('subjects', [])); sch = up(p.get('school')) + ' ' + up(p.get('title'))
    if 'ΛΥΚΕΙ' in sch or 'ΓΕΛ' in sch.split() or 'ΕΠΑΛ' in sch or 'ΠΡΟΣΑΝΑΤΟΛ' in txt or 'ΑΛΓΕΒΡ' in txt:
        return 'Λύκειο'
    if 'ΓΥΜΝΑΣ' in sch or any(k in txt for k in ('ΑΡΧΑΙ', 'ΧΗΜΕΙ', 'ΒΙΟΛΟΓ', 'ΚΟΙΝ. ΠΟΛ', 'ΟΙΚΙΑΚΗ ΟΙΚ')):
        return 'Γυμνάσιο'
    return 'Δημοτικό'


def level(p):
    l=(p.get('framework') or {}).get('level','Δημοτικό')
    return l if l in LEVELS else 'Δημοτικό'

def grades(p):
    return LEVEL_GRADES[level(p)]

def hours_defaults(lv):
    return TEACHER_HOURS_DEFAULT if lv=='Δημοτικό' else TEACHER_HOURS_SECONDARY

def framework(p):
    f=dict(p.get('framework') or {})
    d=hours_defaults(level(p));th={**d,**(f.get('teacher_hours') or {})}
    if not th.get('director') and d['director']:th['director']=[r[:] for r in d['director']]   # παλιά έργα χωρίς τιμές διευθυντών
    th.setdefault('director_years',20)
    st=f.get('teacher_hours') or {}
    if 'deputy_hours' not in st and st.get('deputy_reduction'):th['deputy_hours']=[]   # παλιά έργα με δική τους μείωση υποδιευθυντή
    return {'level':level(p),'curriculum_source':f.get('curriculum_source',''),'teacher_hours':th,'optional':f.get('optional') or {}}

def over(t,n):
    """Υπηρεσία «άνω των n ετών» με έτη-μήνες-ημέρες όπως στο myschool (υπολογισμένα έως 31/12)."""
    y=t.get('years') or 0
    return y>n or (y==n and bool(t.get('years_m') or t.get('years_d')))

def _band(th,t):
    """Ώρες από τον πίνακα ετών. Δευτεροβάθμια (bands_upto): «έως 6», «6 έτη και 1 ημέρα έως 12»… — το όριο ανήκει στην κάτω κατηγορία.
    Πρωτοβάθμια: «από 10 έτη» — το όριο ανήκει στην επάνω κατηγορία."""
    y=t.get('years')
    if y is None:return None
    if th.get('bands_upto'):
        return next((h for a,b,h in th['bands'] if (a==0 or over(t,a)) and not over(t,b)),None)
    return next((h for a,b,h in th['bands'] if a<=y<b),None)

def required_hours(p,t):
    """Υποχρεωτικό διδακτικό ωράριο εκπαιδευτικού ή None αν δεν αρκούν τα στοιχεία."""
    if t.get('hours_override') is not None:return t['hours_override']
    th=framework(p)['teacher_hours'];pos=p.get('positions')
    if not pos and level(p)!='Δημοτικό':pos=len(p.get('classes') or []) or None   # δευτεροβάθμια: αριθμός τμημάτων
    role=t.get('role','')
    if role=='director':
        if not pos:return None
        for r in th['director']:
            if r[0]<=pos<=r[1]:
                if len(r)>3 and r[3]!=r[2]:
                    y=t.get('years')
                    if y is None:return None
                    h=r[3] if over(t,th.get('director_years',20)) else r[2]
                else:h=r[2]
                b=_band(th,t)
                return min(h,b) if b is not None else h   # ευνοϊκότερη ρύθμιση
        return None
    if role=='deputy' and th.get('deputy_hours'):
        a,b=th['deputy_hours']
        if a==b:return a
        y=t.get('years')
        if y is None:return None
        h=b if over(t,th.get('director_years',20)) else a
        bb=_band(th,t)
        return min(h,bb) if bb is not None else h
    if pos and pos<=th['small_school_max']:h=th['small_school_hours']
    else:
        h=_band(th,t)
        if h is None:return None
    if role=='deputy':h-=th['deputy_reduction']
    return h

def teacher_hours_check(p):
    """{teacher_id: {'required','assigned','text'}} για όσους έχουν δηλωμένα στοιχεία."""
    import admin
    out={};extra=admin.counted_hours(p)
    for t in p['teachers']:
        req=required_hours(p,t)
        if req is None:continue
        eh,etxt=extra.get(t['id'],(0,''))
        got=sum(l['hours'] for l in p['lessons'] if t['id'] in l['teachers'])+eh
        txt='' if got==req else (str(got)+' ώρες ανάθεση'+(' (μαζί '+etxt+')' if etxt else '')+' αντί για '+str(req)+' υποχρεωτικές ('+('λείπουν '+str(req-got) if got<req else 'περισσεύουν '+str(got-req))+')')
        out[t['id']]={'required':req,'assigned':got,'text':txt,'extra':etxt}
    return out

def curriculum_check(p):
    """Αποκλίσεις ωρών ανά τμήμα από το επίσημο ωρολόγιο: {class_id: [κείμενα]}."""
    cur=p.get('curriculum') or {};S=mapping(p,'subjects');out={};opt=framework(p)['optional']
    for c in p['classes']:
        g=grade_of(c);want=cur.get(g)
        if not g or not want:continue
        have={}
        for l in p['lessons']:
            if c['id'] in l['classes']:have[l['subject']]=have.get(l['subject'],0)+l['hours']
        msgs=[]
        for sid,h in want.items():
            if sid in S and not have.get(sid) and sid in opt.get(g,[]):continue
            if have.get(sid,0)!=h:msgs.append(S[sid]['name']+': '+str(have.get(sid,0))+' αντί για '+str(h))
        for sid,h in have.items():
            if sid not in want and sid in S and h:msgs.append(S[sid]['name']+': '+str(h)+(' ώρα' if h==1 else ' ώρες')+', δεν υπάρχει στο επίσημο ωρολόγιο της '+g+'΄')
        if msgs:out[c['id']]=msgs
    return out

def findings(p,complete=False):return R.evaluate(p,complete)
def validation(p,complete=False):
    """Παραβιάσεις υποχρεωτικών κανόνων (κείμενα)."""
    check_structure(p);return [f['text'] for f in R.evaluate(p,complete) if f['hard']]
def warnings(p):
    """Επιθυμητοί κανόνες που δεν τηρούνται, με τη σειρά βαρύτητας."""
    check_structure(p);return sorted([f for f in R.evaluate(p,True) if not f['hard']],key=lambda f:-f['penalty'])

def save(p,path):
    check_structure(p);path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():
        from datetime import datetime
        backup=path.parent/'backups';backup.mkdir(exist_ok=True)
        (backup/(path.stem+'_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.json')).write_bytes(path.read_bytes())
    fd,temp=tempfile.mkstemp(dir=path.parent,suffix='.tmp')
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:json.dump(p,f,ensure_ascii=False,indent=2);f.flush();os.fsync(f.fileno())
        os.replace(temp,path)
    finally:
        if os.path.exists(temp):os.unlink(temp)

def load(path):return check_structure(json.loads(Path(path).read_text(encoding='utf-8')))

def solve(p,seconds=30,cancel=None):
    check_structure(p)
    result=R.solve(p,seconds,cancel)
    if 'project' not in result:
        return result
    q=result['project'];errors=validation(q,True)
    if errors:raise ValueError('Η παραγόμενη λύση απέτυχε στον ανεξάρτητο έλεγχο: '+'; '.join(errors[:5]))
    soft=warnings(q);gaps=R.gap_total(q,False)
    result['message']='Έγκυρη λύση'+(' (βέλτιστη για τους κανόνες)' if result['status']=='optimal' else '')+'. Κενά εκπαιδευτικών: '+str(gaps)+'. '+('Όλοι οι επιθυμητοί κανόνες τηρούνται.' if not soft else 'Επιθυμητοί κανόνες που δεν τηρήθηκαν πλήρως: '+str(len(soft))+' (δείτε «Έλεγχος»).')
    result['score']=R.score(q)
    return result


def move_bump(project, event_id, place):
    """Μετακίνηση σε θέση που είναι πιασμένη: όσα συγκρούονται (ίδιος εκπαιδευτικός/τμήμα/ομάδα/αίθουσα)
    πηγαίνουν στις εκκρεμότητες (μαζί με τα ταυτόχρονα συνδεδεμένα τους). Κλειδωμένα δεν μετακινούνται."""
    p=copy.deepcopy(project);ls=mapping(p,'lessons')
    e=next(x for x in p['events'] if x['id']==event_id)
    if e['locked']:raise ValueError('Η διδασκαλία είναι κλειδωμένη.')
    l=ls[e['lesson']];d,i=place;cover=set(range(i,i+l['duration']))
    # συνδεδεμένα «ταυτόχρονα» μαθήματα μετακινούνται μαζί: οι πόροι τους μετρούν κι αυτοί
    mine={e['id']};res=set(R.resources(p,l));covers={e['id']:cover}
    for k in p.get('links',[]):
        if e['lesson'] in k['lessons'] and e['place']:
            for x in p['events']:
                if x['lesson'] in k['lessons'] and x['lesson']!=e['lesson'] and x['place']==e['place']:
                    mine.add(x['id']);res|=set(R.resources(p,ls[x['lesson']]))
    bumped=[]
    for x in p['events']:
        if x['id'] in mine or not x['place']:continue
        lx=ls[x['lesson']]
        if x['place'][0]!=d or not cover&set(range(x['place'][1],x['place'][1]+lx['duration'])):continue
        if not res&set(R.resources(p,lx)):continue
        if x['locked']:raise ValueError('Στη θέση αυτή υπάρχει κλειδωμένο μάθημα ('+R.lesson_label(p,lx)+'). Ξεκλειδώστε το πρώτα.')
        bumped.append(x)
    extra=[]
    for x in bumped:  # και οι ταυτόχρονοι εταίροι τους
        for k in p.get('links',[]):
            if x['lesson'] in k['lessons']:
                for y in p['events']:
                    if y['lesson'] in k['lessons'] and y is not x and y['place']==x['place'] and y['id'] not in mine and y not in bumped and y not in extra:
                        if y['locked']:raise ValueError('Στη θέση αυτή υπάρχει κλειδωμένο μάθημα ('+R.lesson_label(p,ls[y['lesson']])+').')
                        extra.append(y)
    for x in bumped+extra:x['place']=None
    return move_event(p,event_id,place),[x['id'] for x in bumped+extra]


def move_event(project, event_id, place, swap_id=None):
    p=copy.deepcopy(project)
    e=next(e for e in p['events'] if e['id']==event_id)
    if e['locked']:raise ValueError('Η διδασκαλία είναι κλειδωμένη.')
    linked={lid for k in p.get('links',[]) for lid in k['lessons']}
    if swap_id:
        other=next(x for x in p['events'] if x['id']==swap_id)
        if e['lesson'] in linked or other['lesson'] in linked:raise ValueError('Τα ταυτόχρονα μαθήματα δεν ανταλλάσσονται· μετακινήστε τα σε ελεύθερη θέση και θα πάνε μαζί.')
        if other is e or not e['place'] or not other['place']:raise ValueError('Μη έγκυρη ανταλλαγή.')
        if other['locked']:raise ValueError('Η δεύτερη διδασκαλία είναι κλειδωμένη.')
        e['place'],other['place']=other['place'],e['place']
    else:
        old=e['place'];e['place']=place
        if e['lesson'] in linked and old:
            # Οι διδασκαλίες των άλλων πλευρών του δεσίματος στην ίδια θέση μετακινούνται μαζί
            ls=mapping(p,'lessons');dur=ls[e['lesson']]['duration']
            for k in p['links']:
                if e['lesson'] not in k['lessons']:continue
                for side in R.link_sides(p,k):
                    if e['lesson'] in side:continue
                    mate=next((x for x in p['events'] if x['lesson'] in side and x['place']==old and ls[x['lesson']]['duration']==dur and x is not e),None)
                    if mate:
                        if mate['locked']:raise ValueError('Η ταυτόχρονη διδασκαλία είναι κλειδωμένη.')
                        mate['place']=place
    check_structure(p)
    # Απορρίπτεται μόνο ό,τι ΧΕΙΡΟΤΕΡΕΥΕΙ υποχρεωτικό κανόνα· υπάρχουσες εκκρεμότητες δεν μπλοκάρουν.
    before={f['key']:f['amount'] for f in R.evaluate(project) if f['hard']}
    worse=[f['text'] for f in R.evaluate(p) if f['hard'] and f['amount']>before.get(f['key'],0)]
    if worse:raise ValueError('Η μετακίνηση απορρίφθηκε: '+' · '.join(worse[:5]))
    return p
